from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.
def players(request):
    template = loader.get_template('index.html')
    return HttpResponse(template.render())
def csk(request):
    template = loader.get_template('csk.html')
    return HttpResponse(template.render())
def rcb(request):
    template = loader.get_template('rcb.html')
    return HttpResponse(template.render())