from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Students
# Create your views here.
def homepage(request):
    students=Students.objects.all().values()
    template=loader.get_template('students.html')
    context={'allstudents':students,}
    return HttpResponse(template.render(context,request,))
def loginpage(req):
    return render(req,"login.html")
def cgpa_calculator(req):
    return render(req,"cgpa.html")
